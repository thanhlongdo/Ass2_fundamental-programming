#ifndef ROLE_H_
#define ROLE_H_

class role
{
private:

public:

};

class reader:public role
{
private:

public:

};

class book_manager:public role
{
private:

public:
};

class account_manager:public role
{
private:

public:
};
#endif // !ROLE_H_
