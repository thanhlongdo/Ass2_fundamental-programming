#include<iostream>
#include"role.h"
#include"data_structure.h"
#include"display.h"
int main()
{
	system("color 1A");

	main_screen();

	system("pause");
	return 0;
}