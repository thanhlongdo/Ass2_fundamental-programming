﻿#ifndef BOOK_H_
#define BOOK_H_
#include<iostream>
#include<string>
using namespace std;

struct book
{
	int id;
	string name;
	string author;
	int total;
};

struct user
{
	int user_id;
	string full_name;
	int citizen_id;
	string career;
	string email;
};

struct account {
	int user_id;
	string account_name;
	string password;
	int role;
	int status;
};

struct time_day {
	int day;
	int month;
	int year;
};

struct borrow_table {
	int book_id;
	int user_id;
	time_day start_day;
	time_day end_day;
	int status;
};


#endif