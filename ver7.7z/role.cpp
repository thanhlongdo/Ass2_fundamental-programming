﻿#include"role.h"

//add a book to the library
void book_manager::insert_book() {
	ofstream book_file;
	string book_name,author_name;
	int total_book;
	int total;

	total = seek_total_book();//return the total book number

	//open file to appending
	book_file.open("file/book_file.txt",fstream::app);
	
	print_logo();
	cout << left << setw(45) << " " << "Add a book to the libary\n";
	cout << left << setw(45) << " " << "1.Book name:\n";
	cin.ignore(256, '\n');
	getline(cin, book_name);
	cout << left << setw(45) << " " << "2.Author name:\n";
	getline(cin, author_name);
	cout << left << setw(45) << " " << "3.The total book number:\n";
	cin >> total_book;

	//write to file
	book_file << total + 1 << endl;
	book_file << book_name<<endl;
	book_file << author_name << endl;
	book_file << total_book << endl;
	book_file << "-------------------------------------------------\n";

	//close file
	book_file.close();
	
	//show to console
	system("CLS");
	print_logo();
	cout << left << setw(45) << " " << left << setw(20) << "Insert successfully\n";
	cout << left << setw(45) << " " << left << setw(20) << "1.Book ID: " << total + 1 << endl;
	cout << left << setw(45) << " " << left << setw(20) << "2.Book name:" << book_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "3.Author name: " << author_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "4.Quantity: " << total_book << endl;

	cout << left << setw(45) << " " << left << setw(20) << "Press any key to comeback " << total_book << endl;
	system("pause");
	//comeback
	return;
}

//delete a book from the library
void book_manager::delete_book() {
	int total_book = seek_total_book();
	vector<book> book_array(total_book);
	int book_id;
	
	book_array = load_book();


	print_logo();
	cout << left << setw(45) << " " << "Enter your book ID which you want to delete:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << left << setw(45) << " " << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		book_array.erase(book_array.begin() + book_id - 1);
	
		cout << left << setw(45) << " " << "book (ID=" << book_id << ") has been deleted.\n";
	}

	//write data to book_file
	write_book(book_array);

	cout << left << setw(45) << " " << "press any key to comeback" << endl;
	system("pause");
}

//seek the total book number form file book_file.txt
int role::seek_total_book()
{
	int total_book=0;
	ifstream book_file;

	book_file.open("file/book_file.txt");
	if (book_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_book = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			getline(book_file, tem_string);
			i++;
			if (book_file.eof())
				break;
			else if (i % 5 == 1)
			{
				total_book++;
			}
		}
	}

	book_file.close();
	return total_book;
}

//load data from book_file.txt to vector<book>
vector<book> role::load_book()
{
	ifstream book_file;
	int total_book = seek_total_book();
vector<book> book_array(total_book);
string tem_string;

//open file
book_file.open("file/book_file.txt");

int i = 0;
while (true)
{
	getline(book_file, tem_string);
	i++;

	if (book_file.eof())
		break;

	if (i % 5 == 1)
		book_array[i / 5].id = stoi(tem_string);
	else if (i % 5 == 2)
		book_array[i / 5].name = tem_string;
	else if (i % 5 == 3)
		book_array[i / 5].author = tem_string;
	else if (i % 5 == 4)
		book_array[i / 5].total = stoi(tem_string);

}

//for (int i = 0; i < total_book; i++)
//{
//	cout << left << setw(20) << "User ID: " << book_array[i].id << "\n";
//	cout << left << setw(20) << "Full name: " << book_array[i].name << "\n";
//	cout << left << setw(20) << "Citizen ID: " << book_array[i].author<< "\n";
//	cout << left << setw(20) << "Career: " << book_array[i].total << "\n";
//}
book_file.close();
return book_array;
}

//check book id has been exist ?`
bool role::check_book_exist(int id)
{
	int total_book = seek_total_book();
	vector<book> book_array(total_book);

	book_array = load_book();
	for (int i = 0; i < total_book; i++)
	{
		if (book_array[i].id == id)
			return true;
	}
	return false;
}

//write data to book_file.txt
void role::write_book(vector<book> book_array) {
	ofstream book_file;

	//open file
	book_file.open("file/book_file.txt");

	for (int i = 0; i < book_array.size(); i++)
	{
		book_file << book_array[i].id << endl;
		book_file << book_array[i].name << endl;
		book_file << book_array[i].author << endl;
		book_file << book_array[i].total << endl;
		book_file << "----------------------------------------------\n";
	}
}

//modify book information
void book_manager::modify_book() {
	vector<book> book_array = load_book();
	int book_id;
	string book_name, book_author;
	int quantity;
	int book_index;

	print_logo();
	cout << left << setw(45) << " " << "You book id which you want to modify:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << left << setw(45) << " " << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		cout << left << setw(45) << " " << "1.New book name:\n";
		cin.ignore(256, '\n');
		getline(cin, book_name);

		cout << left << setw(45) << " " << "2.New author name:\n";
		//cin.ignore(256, '\n');
		getline(cin, book_author);
		cout << left << setw(45) << " " << "3.New quantity:\n";
		//cin.ignore(256, '\n');
		cin >> quantity;


		//find book index
		for (int i = 0; i < book_array.size(); i++){
			if (book_array[i].id == book_id)
				book_index=i;
		}

		//chang data in vector
		book_array[book_index].name = book_name;
		book_array[book_index].author = book_author;
		book_array[book_index].total = quantity;

		//write data to file
		write_book(book_array);

		cout << left << setw(45) << " " << "you have modified book successfully\n";
		system("pause");
		
	}
}

//show all book in the library
void role::show_all_book() {
	vector<book> book_array = load_book();

	print_logo();
	cout << left << setw(45) << " " << "Show all book in the library\n\n";
	cout << left << setw(45) << " " << "--------------------------------------------\n";
	for (int i = 0; i < book_array.size(); i++)
	{
		cout << left << setw(45) << " " << left<<setw(15)<<"Book id:"<< i+1 << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book name:" << book_array[i].name << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book author:" << book_array[i].author << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book quantity:" << book_array[i].total << endl;
		cout << left << setw(45) << " " << "--------------------------------------------\n";
	}

	cout << "\npress any key to comeback\n";
	system("pause");

	system("CLS");
}

//find a book from library
void role::find_book() {

	vector<book> book_array = load_book();
	string book_name;

	print_logo();
	cout << left << setw(45) << " " << "Find a book\n";
	cout << left << setw(45) << " " << "Enter your book name which you want to find:\n";
	cin.ignore(256, '\n');
	getline(cin, book_name);
	cout << left << setw(45) << " " << "result is:\n";
	cout << left << setw(45) << " " << "--------------------------------\n";
	for (int i = 0; i < book_array.size(); i++)
	{
		if (book_array[i].name == book_name)
		{
			cout << left << setw(45) << " " << left << setw(15) << "Book ID: " << i + 1 << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book name: " << book_array[i].name << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book author: " << book_array[i].author << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book quantity: " << book_array[i].total << endl;
			cout << left << setw(45) << " " << "--------------------------------\n";
		}
	}

	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");

	system("CLS");
}


//load from account_file.txt to vector
vector<account> role::load_account()
{
	ifstream account_file;
	string tem_string;
	int total_account = seek_total_account();
	vector<account> account_array(total_account);

	account_file.open("file/account_file.txt");

	int i = 0;
	while (true)
	{
		account_file >> tem_string;
		i++;

		if (account_file.eof())
			break;

		if (i % 6 == 1)
			account_array[i / 6].user_id = stoi(tem_string);
		else if (i % 6 == 2)
			account_array[i / 6].account_name = tem_string;
		else if (i % 6 == 3)
			account_array[i / 6].password = tem_string;
		else if (i % 6 == 4)
			account_array[i / 6].role = stoi(tem_string);
		else if (i % 6 == 5)
			account_array[i / 6].status = stoi(tem_string);
	}

	//close file
	account_file.close();

	return account_array;

}

//show personal information
void role::see_personal_information(account account_login) {
	int total_user = seek_total_user();
	vector<user> user_array = load_user(total_user);

	print_logo();
	cout << left << setw(45) << " " << "Personal information user\n";
	cout << left << setw(45) << " " << "--------------------------\n\n";

	for (int i = 0; i < user_array.size(); i++)
	{
		if (user_array[i].user_id == account_login.user_id)
		{
			cout << left << setw(45) << " " <<left<<setw(20)<< "1.User ID:" << user_array[i].user_id << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User name:" << user_array[i].full_name << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.Citizen ID:" << user_array[i].citizen_id << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User career:" << user_array[i].career << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User email:" << user_array[i].email << endl;
			
		}
	}
	
	
	cout << left << setw(45) << " " << "press any key to comeback:" <<endl;
	system("pause");
	
	//comeback to main screen
	system("CLS");
	return;
}

void role::change_password() {
	vector<account> account_array = load_account();
	string account_name, new_password,account_password;
	bool flat = false;

	print_logo();
	cout << left << setw(45) << " " << "Change password\n";
	cout << left << setw(45) << " " << "---------------\n";

	cout << left << setw(45) << " " << "1.Your account name:\n";
	cin >> account_name;
	cout << left << setw(45) << " " << "1.Your account password:\n";
	cin >> account_password;


	for (int i = 0; i < account_array.size(); i++) {
		if (account_array[i].account_name == account_name&&account_array[i].password==account_password)
		{
			flat = true;

			cout << left << setw(45) << " " << "your new password:\n";
			cin >> new_password;

			//change password
			account_array[i].password = new_password;

			//out loop
			break;
		}
	}

	if (flat == false)
	{
		cout << left << setw(45) << " " << "your account or password is wrong!!!\n";
		//comeback

		cout << left << setw(45) << " " << "Press any key to comeback\n";
		system("pause");
		return;
	}
	//write to file
	write_account(account_array);

	//comeback
	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");
	return;
	
}

//check account exist 
bool role::check_account_exist(string account_name) {
	vector<account> account_array = load_account();

	for (int i = 0; i < account_array.size(); i++)
	{
		if (account_array[i].account_name == account_name)
			return true;
	}

	return false;
}

//write data to file txt
void role::write_account(vector<account> account_array) {
	ofstream account_file;

	//open file
	account_file.open("file/account_file.txt");

	for (int i = 0; i < account_array.size(); i++)
	{
		account_file<< account_array[i].user_id << endl;
		account_file << account_array[i].account_name << endl;
		account_file << account_array[i].password << endl;
		account_file << account_array[i].role << endl;
		account_file << account_array[i].status << endl;
		account_file << "----------------------------------------------\n";
	}
}

//seek total account
int role::seek_total_account(){
	int total_account = 0;
	ifstream account_file;
	string tem_string;

	account_file.open("file/account_file.txt");
	if (account_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_account = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			account_file >> tem_string;
			i++;
			if (account_file.eof())
				break;
			else if (i % 6 == 1)
			{
				total_account++;
			}
		}
	}

	account_file.close();
	return total_account;
}


//mượn sách
void reader::borrow_book(account account_id) {
	int book_id;
	vector<book> book_array = load_book();
	vector<borrow_table> borrow_array = load_borrow_book();
	int book_index;
	int day_pay, month_pay, year_pay;
	int day_borrow, month_borrow, year_borrow;
	borrow_table borrow;

//	vector<book> book_waiter

	print_logo();
	cout << left << setw(45) << " " << "Borrow a book\n";
	cout << left << setw(45) << " " << "-------------\n\n";


	cout << left << setw(45) << " " << "Your book ID which you want to borrow:\n";
	cin >> book_id;
	cout << left << setw(45) << " " << "input day/month/year you want borrow\n";
	cin >> day_borrow;
	cin >> month_borrow;
	cin >> year_borrow;
	cout << left << setw(45) << " " << "input day/month/year you want pay\n";
	cin >> day_pay;
	cin >> month_pay;
	cin >> year_pay;

	//don't exist book id
	if (check_book_exist(book_id) == false)
	{
		cout << left << setw(45) << " " << "Your book ID doesn't exist\n";

		//return 
		cout << left << setw(45) << " " << "Press any key to comeback\n";
		system("pause");
		return;
	}

	//find book
	for (int i = 0; i < book_array.size(); i++)
	{
		if (book_array[i].id == book_id) {
			book_index = i;
		}
	}

	//quantity==, can't borrow
	if (book_array[book_index].total == 0||borrow_exist(book_id,account_id.user_id)==true)
	{
		cout << left << setw(45) << " " << "Your book, don't available\n";

		//return 
		cout << left << setw(45) << " " << "Press any key to comeback\n";
		system("pause");
		return;
	}


	book_array[book_index].total--;//delete quantity

	borrow.book_id = book_id;
	borrow.user_id = account_id.user_id;
	//
	//time_t t = time(0);   // get time now
	//struct tm * now = localtime(&t);

	borrow.start_day.day = day_borrow;
	borrow.start_day.month = month_borrow;
	borrow.start_day.year = year_borrow;
	borrow.end_day.day = day_pay;
	borrow.end_day.month = month_pay;
	borrow.end_day.year = year_pay;
	borrow.status = 0;

	borrow_array.push_back(borrow);
	
	//write to file
	write_borrow(borrow_array);
	write_book(book_array);
}

//load data from borrow_file.txt to vector
vector<borrow_table> role::load_borrow_book() {

	ifstream borrow_file;
	int total_borrow= seek_total_borrow();
	vector<borrow_table> book_array(total_borrow);
	string tem_string;

	//open file
	borrow_file.open("file/borow_table.txt");

	int i = 0;
	while (true)
	{
		getline(borrow_file, tem_string);
		i++;

		if (borrow_file.eof())
			break;

		if (i % 10 == 1)
			book_array[i / 10].book_id= stoi(tem_string);
		else if (i % 10 == 2)
			book_array[i / 10].user_id = stoi(tem_string);
		else if (i % 10 == 3)
			book_array[i / 10].start_day.day= stoi(tem_string);
		else if (i % 10 == 4)
			book_array[i / 10].start_day.month = stoi(tem_string);
		else if (i %10 == 5)
			book_array[i / 10].start_day.year = stoi(tem_string);
		else if (i % 10 == 6)
			book_array[i / 10].end_day.day = stoi(tem_string);
		else if (i % 10 == 7)
			book_array[i / 10].end_day.month = stoi(tem_string);
		else if (i % 10 == 8)
			book_array[i / 10].end_day.year = stoi(tem_string);
		else if (i % 10 ==9 )
			book_array[i / 10].status = stoi(tem_string);
	
	}

	//for (int i = 0; i < total_book; i++)
	//{
	//	cout << left << setw(20) << "User ID: " << book_array[i].id << "\n";
	//	cout << left << setw(20) << "Full name: " << book_array[i].name << "\n";
	//	cout << left << setw(20) << "Citizen ID: " << book_array[i].author<< "\n";
	//	cout << left << setw(20) << "Career: " << book_array[i].total << "\n";
	//}
	borrow_file.close();
	return book_array;
}

//find total book number in borrow_table.txt
int role::seek_total_borrow() {
	int total_borrow = 0;
	ifstream borrow_file;
	string tem_string;

	borrow_file.open("file/borow_table.txt");
	if (borrow_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_borrow = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			getline(borrow_file, tem_string);
			i++;
			if (borrow_file.eof())
				break;
			else if (i % 13 == 1)
			{
				total_borrow++;
			}
		}
	}

	borrow_file.close();
	return total_borrow;
}

//write data to file borrow_table.txt
void role::write_borrow(vector<borrow_table> borrow) {
	ofstream borrow_file;

	//open file
	borrow_file.open("file/borow_table.txt");

	for (int i = 0; i < borrow.size(); i++)
	{
		borrow_file << borrow[i].book_id << endl;
		borrow_file << borrow[i].user_id << endl;
		borrow_file << borrow[i].start_day.day << endl;
		borrow_file << borrow[i].start_day.month << endl;
		borrow_file << borrow[i].start_day.year << endl;
		borrow_file << borrow[i].end_day.day << endl;
		borrow_file << borrow[i].end_day.month << endl;
		borrow_file << borrow[i].end_day.year << endl;
		borrow_file << borrow[i].status << endl;
		borrow_file << "-------------------------------"<< endl;
	}
}


//allow borrow permission
void book_manager::allow_borrow()
{
	vector<borrow_table> borrow_array = load_borrow_book();
	int book_id, user_id;
	bool flat = false;

	print_logo();
	cout << left << setw(45) << " " << "Allow borrow book\n";
	cout << left << setw(45) << " " << "-----------------\n\n";

	for (int i = 0; i < borrow_array.size(); i++)
	{
	if (borrow_array[i].status == 0)
	{
		cout << left << setw(45) << " " << left << setw(15) << "Book ID:" << borrow_array[i].book_id << endl;
		cout << left << setw(45) << " " << left << setw(15) << "User ID:" << borrow_array[i].user_id << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Borrow time:" << borrow_array[i].start_day.day << "/" << borrow_array[i].start_day.month << "/" << borrow_array[i].start_day.year << endl;
		cout << left << setw(45) << " " << left << setw(15) << "pay time:" << borrow_array[i].end_day.day << "/" << borrow_array[i].end_day.month << "/" << borrow_array[i].end_day.year << endl;
		cout << left << setw(45) << " " << "-----------------------------------------------\n";

		flat = true;
	}

	}
	//don't have any requietment
	if (flat == false)
	{
		cout << left << setw(45) << " " << "Don't have any requirement\n";
		cout << left << setw(45) << " " << "------------------------\n\n";

		//comeback
		cout << left << setw(45) << "Press any key to comeback" << "\n";
		system("pause");
return;
	}

	cout << left << setw(45) << " " << "choose book id, user id, which you allow to borrow books\n";
	cin >> book_id;
	cin >> user_id;


	for (int i = 0; i < borrow_array.size(); i++)
	{
		if (borrow_array[i].book_id == book_id&&borrow_array[i].user_id == user_id)
		{
			borrow_array[i].status = 1;
		}

	}

	//write to file
	write_borrow(borrow_array);
	//comeback
	cout << left << setw(45) << "Press any key to comeback" << "\n";
	system("pause");
	return;
}

//check
bool role::borrow_exist(int book_id, int user_id) {
	vector<borrow_table> borrow_array = load_borrow_book();

	for (int i = 0; i < borrow_array.size(); i++)
	{
		if (borrow_array[i].book_id == book_id&&borrow_array[i].user_id == user_id)
			return true;
	}

	return false;
}

//pay book
void reader::pay_book(account account_id) {

	vector<borrow_table> borrow_array = load_borrow_book();
	vector<book> book_array = load_book();
	int book_id, user_id;

	print_logo();
	cout << left << setw(45) << " " << "Pay a book\n";
	cout << left << setw(45) << " " << "----------\n\n";

	for (int i = 0; i < borrow_array.size(); i++)
	{
		if (borrow_array[i].status == 1 && borrow_array[i].user_id == account_id.user_id)
		{
			cout << left << setw(45) << " " << left << setw(15) << "Book ID:" << borrow_array[i].book_id << endl;
			cout << left << setw(45) << " " << left << setw(15) << "User ID:" << borrow_array[i].user_id << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Borrow time:" << borrow_array[i].start_day.day << "/" << borrow_array[i].start_day.month << "/" << borrow_array[i].start_day.year << endl;
			cout << left << setw(45) << " " << left << setw(15) << "pay time:" << borrow_array[i].end_day.day << "/" << borrow_array[i].end_day.month << "/" << borrow_array[i].end_day.year << endl;
			cout << left << setw(45) << " " << "-----------------------------------------------\n";

		}
	}


	cout << left << setw(45) << " " << "choose book id, user id, which you want to pay\n";
	cin >> book_id;
	cin >> user_id;


	//delete in borrow array
	for (int i = 0; i < borrow_array.size(); i++)
	{
		if (borrow_array[i].book_id == book_id&&borrow_array[i].user_id == user_id)
		{
			borrow_array.erase(borrow_array.begin() + i);
		}
	}

	for (int i = 0; i < book_array.size(); i++)
	{
		if (book_array[i].id == book_id)
			book_array[i].total++;
	}

	//write data to file
	write_book(book_array);
	write_borrow(borrow_array);
	//comeback
	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");
	return;
}

//active account manager
void account_manager::active_account() {
	vector<account> account_array = load_account();
	string account_id;
	int role;

	print_logo();
	cout << left << setw(45) << " " << "Active a account\n";
	cout << left << setw(45) << " " << "------------------\n\n";

	for (int i = 0; i < account_array.size(); i++) {
		if (account_array[i].status == 0)
		{
			cout << left << setw(45) << " " << left << setw(15) << "User ID: " << account_array[i].user_id << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Account name: " << account_array[i].account_name << endl;
			cout << left << setw(45) << " " << "--------------------------------------------------\n";
		}
	}

	cout << left << setw(45) << " " << "input account name which you want to active\n";
	cin >> account_id;
	cout << left << setw(45) << " " << "Assign the role to this account\n";
	cin >> role;


	//change element in vector
	for (int i = 0; i < account_array.size(); i++)
	{
		if (account_array[i].account_name == account_id) {
			account_array[i].status = 1;
			account_array[i].role = role;
		}
	}

	//write to file

	write_account(account_array);
	//comeback
	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");
	return;

}

void account_manager::reset_password() {
	string account_name;
	vector<account> account_array = load_account();


	print_logo();
	cout << left << setw(45) << " " << "Reset password\n";
	cout << left << setw(45) << " " << "------------------\n\n";


	cout << left << setw(45) << " " << "Your account name: \n";
	cin >> account_name;

	for (int i = 0; i < account_array.size(); i++)
	{
		if (account_array[i].account_name == account_name)
		{
			account_array[i].password = '0000';//reset password
		}
	}
	cout << left << setw(45) << " " << "successfully, new password is: 0000: \n";
	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");
	return;
}