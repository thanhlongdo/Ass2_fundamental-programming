﻿#ifndef BOOK_H_
#define BOOK_H_
#include<iostream>
#include<string>
using namespace std;

struct book
{
	int id;
	string name;
	string author;
	int total;
};

struct user
{
	int user_id;
	string full_name;
	int citizen_id;
	string career;
	string email;
};

struct account {
	int user_id;
	string account_name;
	string password;
	int role;
	int status;
};

#endif