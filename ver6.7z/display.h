#ifndef DISPLAY_H_
#define DISPLAY_H_
#include<iostream>
#include<vector>
#include"data_structure.h"
#include"role.h"
using namespace std;


void about_us();
void print_logo();
void main_screen();
void create_user();
void create_account();
int seek_total_user();
vector<user> load_user(int total_user );
bool check_user_exist(int user_id);
void login();
void book_manager_screen(account user_login);
#endif // !DISPLAY_H_
