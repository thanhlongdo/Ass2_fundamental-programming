﻿#include"role.h"

//add a book to the library
void book_manager::insert_book() {
	ofstream book_file;
	string book_name,author_name;
	int total_book;
	int total;

	total = seek_total_book();//return the total book number

	//open file to appending
	book_file.open("file/book_file.txt",fstream::app);
	
	print_logo();
	cout << left << setw(45) << " " << "Add a book to the libary\n";
	cout << left << setw(45) << " " << "1.Book name:\n";
	cin.ignore(256, '\n');
	getline(cin, book_name);
	cout << left << setw(45) << " " << "2.Author name:\n";
	getline(cin, author_name);
	cout << left << setw(45) << " " << "3.The total book number:\n";
	cin >> total_book;

	//write to file
	book_file << total + 1 << endl;
	book_file << book_name<<endl;
	book_file << author_name << endl;
	book_file << total_book << endl;
	book_file << "-------------------------------------------------\n";

	//close file
	book_file.close();
	
	//show to console
	system("CLS");
	print_logo();
	cout << left << setw(45) << " " << left << setw(20) << "Insert successfully\n";
	cout << left << setw(45) << " " << left << setw(20) << "1.Book ID: " << total + 1 << endl;
	cout << left << setw(45) << " " << left << setw(20) << "2.Book name:" << book_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "3.Author name: " << author_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "4.Quantity: " << total_book << endl;

	cout << left << setw(45) << " " << left << setw(20) << "Press any key to comeback " << total_book << endl;
	system("pause");
	//comeback
	return;
}

//delete a book from the library
void book_manager::delete_book() {
	int total_book = seek_total_book();
	vector<book> book_array(total_book);
	int book_id;
	
	book_array = load_book();


	print_logo();
	cout << left << setw(45) << " " << "Enter your book ID which you want to delete:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << left << setw(45) << " " << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		book_array.erase(book_array.begin() + book_id - 1);
	
		cout << left << setw(45) << " " << "book (ID=" << book_id << ") has been deleted.\n";
	}

	//write data to book_file
	write_book(book_array);

	cout << left << setw(45) << " " << "press any key to comeback" << endl;
	system("pause");
}

//seek the total book number form file book_file.txt
int role::seek_total_book()
{
	int total_book;
	ifstream book_file;

	book_file.open("file/book_file.txt");
	if (book_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_book = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			getline(book_file, tem_string);
			i++;
			if (book_file.eof())
				break;
			else if (i % 5 == 1)
			{
				total_book = stoi(tem_string);
			}
		}
	}

	book_file.close();
	return total_book;
}

//load data from book_file.txt to vector<book>
vector<book> role::load_book()
{
	ifstream book_file;
	int total_book = seek_total_book();
	vector<book> book_array(total_book);
	string tem_string;

	//open file
	book_file.open("file/book_file.txt");

	int i = 0;
	while (true)
	{
		getline(book_file, tem_string);
		i++;

		if (book_file.eof())
			break;

		if (i % 5 == 1)
			book_array[i/5].id = stoi(tem_string);
		else if (i % 5 == 2)
			book_array[i/5].name = tem_string;
		else if (i % 5 == 3)
			book_array[i/5].author = tem_string;
		else if (i % 5 == 4)
			book_array[i/5].total = stoi(tem_string);

	}

	//for (int i = 0; i < total_book; i++)
	//{
	//	cout << left << setw(20) << "User ID: " << book_array[i].id << "\n";
	//	cout << left << setw(20) << "Full name: " << book_array[i].name << "\n";
	//	cout << left << setw(20) << "Citizen ID: " << book_array[i].author<< "\n";
	//	cout << left << setw(20) << "Career: " << book_array[i].total << "\n";
	//}
	book_file.close();
	return book_array;
}

//check book id has been exist ?`
bool role::check_book_exist(int id)
{
	int total_book = seek_total_book();
	vector<book> book_array(total_book);

	book_array = load_book();
	for (int i = 0; i < total_book; i++)
	{
		if (book_array[i].id==id)
			return true;
	}
	return false;
}

//write data to book_file.txt
void role::write_book(vector<book> book_array) {
	ofstream book_file;
	
	//open file
	book_file.open("file/book_file.txt");
	
	for (int i = 0; i < book_array.size(); i++)
	{
		book_file << i + 1 << endl;
		book_file << book_array[i].name << endl;
		book_file << book_array[i].author << endl;
		book_file << book_array[i].total << endl;
		book_file << "----------------------------------------------\n";
	}
}

//modify book information
void book_manager::modify_book() {
	vector<book> book_array = load_book();
	int book_id;
	string book_name, book_author;
	int quantity;

	print_logo();
	cout << left << setw(45) << " " << "You book id which you want to modify:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << left << setw(45) << " " << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		cout << left << setw(45) << " " << "1.New book name:\n";
		cin.ignore(256, '\n');
		getline(cin, book_name);
		
		cout << left << setw(45) << " " << "2.New author name:\n";
		//cin.ignore(256, '\n');
		getline(cin, book_author);
		cout << left << setw(45) << " " << "3.New quantity:\n";
		//cin.ignore(256, '\n');
		cin >> quantity;

		//chang data in vector
		book_array[book_id - 1].name = book_name;
		book_array[book_id - 1].author = book_author;
		book_array[book_id - 1].total = quantity;

		//write data to file
		write_book(book_array);

		cout << left << setw(45) << " " << "you have modified book successfully\n";
		system("pause");
		
	}
}

//show all book in the library
void role::show_all_book() {
	vector<book> book_array = load_book();

	print_logo();
	cout << left << setw(45) << " " << "Show all book in the library\n\n";
	cout << left << setw(45) << " " << "--------------------------------------------\n";
	for (int i = 0; i < book_array.size(); i++)
	{
		cout << left << setw(45) << " " << left<<setw(15)<<"Book id:"<< i+1 << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book name:" << book_array[i].name << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book author:" << book_array[i].author << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book quantity:" << book_array[i].total << endl;
		cout << left << setw(45) << " " << "--------------------------------------------\n";
	}

	cout << "\npress any key to comeback\n";
	system("pause");

	system("CLS");
}

//find a book from library
void role::find_book() {

	vector<book> book_array = load_book();
	string book_name;

	print_logo();
	cout << left << setw(45) << " " << "Find a book\n";
	cout << left << setw(45) << " " << "Enter your book name which you want to find:\n";
	cin.ignore(256, '\n');
	getline(cin, book_name);
	cout << left << setw(45) << " " << "result is:\n";
	cout << left << setw(45) << " " << "--------------------------------\n";
	for (int i = 0; i < book_array.size(); i++)
	{
		if (book_array[i].name == book_name)
		{
			cout << left << setw(45) << " " << left << setw(15) << "Book ID: " << i + 1 << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book name: " << book_array[i].name << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book author: " << book_array[i].author << endl;
			cout << left << setw(45) << " " << left << setw(15) << "Book quantity: " << book_array[i].total << endl;
			cout << left << setw(45) << " " << "--------------------------------\n";
		}
	}

	cout << left << setw(45) << " " << "Press any key to comeback\n";
	system("pause");

	system("CLS");
}

//mượn sách
void reader::borrow_book() {
	print_logo();
	cout << "Borrow a book" << endl;


}

//load from account_file.txt to vector
vector<account> role::load_account()
{
	ifstream account_file;
	string tem_string;
	vector<account> account_array(100);

	account_file.open("file/account_file.txt");

	int i = 0;
	while (true)
	{
		account_file >> tem_string;
		i++;

		if (account_file.eof())
			break;

		if (i % 6 == 1)
			account_array[i / 6].user_id = stoi(tem_string);
		else if (i % 6 == 2)
			account_array[i / 6].account_name = tem_string;
		else if (i % 5 == 3)
			account_array[i / 6].password = tem_string;
		else if (i % 6 == 4)
			account_array[i / 6].role = stoi(tem_string);
		else if (i % 6 == 5)
			account_array[i / 6].status = stoi(tem_string);
	}

	//close file
	account_file.close();

	return account_array;

}

//show personal information
void role::see_personal_information(account account_login) {
	int total_user = seek_total_user();
	vector<user> user_array = load_user(total_user);

	print_logo();
	cout << left << setw(45) << " " << "Personal information user\n";
	cout << left << setw(45) << " " << "--------------------------\n\n";

	for (int i = 0; i < user_array.size(); i++)
	{
		if (user_array[i].user_id == account_login.user_id)
		{
			cout << left << setw(45) << " " <<left<<setw(20)<< "1.User ID:" << user_array[i].user_id << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User name:" << user_array[i].full_name << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.Citizen ID:" << user_array[i].citizen_id << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User career:" << user_array[i].career << endl;
			cout << left << setw(45) << " " << left << setw(20) << "1.User email:" << user_array[i].email << endl;
			
		}
	}
	
	
	cout << left << setw(45) << " " << "press any key to comeback:" <<endl;
	system("pause");
	
	//comeback to main screen
	system("CLS");
	book_manager_screen(account_login);
}