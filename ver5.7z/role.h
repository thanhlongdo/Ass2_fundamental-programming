#ifndef ROLE_H_
#define ROLE_H_
#include<iostream>
#include<fstream>
#include<iomanip>
#include"display.h"
using namespace std;



class role
{
private:
public:
	int seek_total_book();
	vector<book> load_book();
	bool check_book_exist(int id);
	void write_book(vector<book> book_array);
	void show_all_book();
	void find_book();

};

class reader:public role
{
private:

public:
	void borrow_book();
};

class account_manager :public role {
private:
public:

};//an
class book_manager:public role
{
private:

public:
	void insert_book();
	void delete_book();
	void modify_book();
};


#endif // !ROLE_H_
