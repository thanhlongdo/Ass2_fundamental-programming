﻿#include"role.h"

void book_manager::insert_book() {
	ofstream book_file;
	string book_name,author_name;
	int total_book;
	int total;

	total = seek_total_book();//return the total book number

	//open file to appending
	book_file.open("file/book_file.txt",fstream::app);
	
	print_logo();
	cout << left << setw(45) << " " << "Add a book to the libary\n";
	cout << left << setw(45) << " " << "1.Book name:\n";
	getline(cin, book_name);
	cout << left << setw(45) << " " << "2.Author name:\n";
	getline(cin, author_name);
	cout << left << setw(45) << " " << "3.The total book number:\n";
	cin >> total_book;

	//write to file
	book_file << total + 1 << endl;
	book_file << book_name<<endl;
	book_file << author_name << endl;
	book_file << total_book << endl;
	book_file << "-------------------------------------------------\n";

	//close file
	book_file.close();
	
	//show to console
	system("CLS");
	print_logo();
	cout << left << setw(45) << " " << left << setw(20) << "Insert successfully\n";
	cout << left << setw(45) << " " << left << setw(20) << "1.Book ID: " << total + 1 << endl;
	cout << left << setw(45) << " " << left << setw(20) << "2.Book name:" << book_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "3.Author name: " << author_name << endl;
	cout << left << setw(45) << " " << left << setw(20) << "4.Quantity: " << total_book << endl;


}

void book_manager::delete_book() {
	int total_book = seek_total_book();
	vector<book> book_array(total_book);
	int book_id;
	
	book_array = load_book();


	print_logo();
	cout << left << setw(45) << " " << "Enter your book ID which you want to delete:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		book_array.erase(book_array.begin() + book_id - 1);
	
		cout << "book (ID=" << book_id << ") has been deleted.\n";
	}

	//write data to book_file
	write_book(book_array);
}

//seek the total book number form file book_file.txt
int role::seek_total_book()
{
	int total_book;
	ifstream book_file;

	book_file.open("file/book_file.txt");
	if (book_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_book = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			getline(book_file, tem_string);
			i++;
			if (book_file.eof())
				break;
			else if (i % 5 == 1)
			{
				total_book = stoi(tem_string);
			}
		}
	}

	book_file.close();
	return total_book;
}

//load data from book_file.txt to vector<book>
vector<book> role::load_book()
{
	ifstream book_file;
	int total_book = seek_total_book();
	vector<book> book_array(total_book);
	string tem_string;

	//open file
	book_file.open("file/book_file.txt");

	int i = 0;
	while (true)
	{
		getline(book_file, tem_string);
		i++;

		if (book_file.eof())
			break;

		if (i % 5 == 1)
			book_array[i/5].id = stoi(tem_string);
		else if (i % 5 == 2)
			book_array[i/5].name = tem_string;
		else if (i % 5 == 3)
			book_array[i/5].author = tem_string;
		else if (i % 5 == 4)
			book_array[i/5].total = stoi(tem_string);

	}

	//for (int i = 0; i < total_book; i++)
	//{
	//	cout << left << setw(20) << "User ID: " << book_array[i].id << "\n";
	//	cout << left << setw(20) << "Full name: " << book_array[i].name << "\n";
	//	cout << left << setw(20) << "Citizen ID: " << book_array[i].author<< "\n";
	//	cout << left << setw(20) << "Career: " << book_array[i].total << "\n";
	//}
	book_file.close();
	return book_array;
}

//check book id has been exist ?`
bool role::check_book_exist(int id)
{
	int total_book = seek_total_book();
	vector<book> book_array(total_book);

	book_array = load_book();
	for (int i = 0; i < total_book; i++)
	{
		if (book_array[i].id==id)
			return true;
	}
	return false;
}

//write data to book_file.txt
void role::write_book(vector<book> book_array) {
	ofstream book_file;
	
	//open file
	book_file.open("file/book_file.txt");
	
	for (int i = 0; i < book_array.size(); i++)
	{
		book_file << i + 1 << endl;
		book_file << book_array[i].name << endl;
		book_file << book_array[i].author << endl;
		book_file << book_array[i].total << endl;
		book_file << "----------------------------------------------\n";
	}
}

//modify book information
void book_manager::modify_book() {
	vector<book> book_array = load_book();
	int book_id;
	string book_name, book_author;
	int quantity;

	print_logo();
	cout << "You book id which you want to modify:\n";
	cin >> book_id;

	if (check_book_exist(book_id) == false)
	{
		cout << "error!! this id is not exist." << endl;
		system("pause");
		return;
	}
	else {
		cout << "1.New book name:\n";
		cin.ignore(256, '\n');
		getline(cin, book_name);
		
		cout << "2.New author name:\n";
		//cin.ignore(256, '\n');
		getline(cin, book_author);
		cout << "3.New quantity:\n";
		//cin.ignore(256, '\n');
		cin >> quantity;

		//chang data in vector
		book_array[book_id - 1].name = book_name;
		book_array[book_id - 1].author = book_author;
		book_array[book_id - 1].total = quantity;

		//write data to file
		write_book(book_array);

		cout << "you have modified book successfully\n";
	}
}

//show all book in the library
void role::show_all_book() {
	vector<book> book_array = load_book();

	print_logo();
	cout << left << setw(45) << " " << "Show all book in the library\n\n";
	cout << left << setw(45) << " " << "--------------------------------------------\n";
	for (int i = 0; i < book_array.size(); i++)
	{
		cout << left << setw(45) << " " << left<<setw(15)<<"Book id:"<< i+1 << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book name:" << book_array[i].name << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book author:" << book_array[i].author << endl;
		cout << left << setw(45) << " " << left << setw(15) << "Book quantity:" << book_array[i].total << endl;
		cout << left << setw(45) << " " << "--------------------------------------------\n";
	}

}

//find a book from library
void role::find_book() {
	
	print_logo();

}

//mượn sách
void reader::borrow_book() {
	print_logo();
	cout << "Borrow a book" << endl;


}