#ifndef ROLE_H_
#define ROLE_H_

class reader
{
private:

public:

};

class book_manager
{
private:

public:
};

class account_manager
{
private:

public:
};
#endif // !ROLE_H_
