#include"user.h"

void user::set_user_id(int user_id) {
	this->user_id = user_id;
}

int user::get_user_id() {
	return this->user_id;
}

void user::set_full_name(string full_name) {
	this->full_name = full_name;
}

string user::get_full_name() {
	return full_name;
}

void user::set_citizen_id(int citizen_id) {
	this->citizen_id = citizen_id;
}

int user :: get_citizen_id() {
	return this->citizen_id;
}

void user::set_career(string career) {
	this->career = career;
}

string user::get_career() {
	return this->career;
}

void user::set_email(string email) {
	this->email = email;
}

string user::get_email() {
	return this->email;
}
