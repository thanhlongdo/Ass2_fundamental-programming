#ifndef USER_H_
#define USER_H_
#include<iostream>
#include<string>
using namespace std;
class user
{
private:
	int user_id;
	string full_name;
	int citizen_id;
	string career;
	string email;
public:
	void set_user_id(int user_id);
	int get_user_id();
	
	void set_full_name(string full_name);
	string get_full_name();
	
	void set_citizen_id(int citizen_id);
	int get_citizen_id();

	void set_career(string career);
	string get_career();

	void set_email(string email);
	string get_email();
};
#endif 