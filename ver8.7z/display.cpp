#include"display.h"
#include<iomanip>
#include<fstream>
#include<string>

//in thong tin
void about_us()
{
	int choose;

	print_logo();

	cout << left << setw(45) << " " << "Team members:\n";
	cout << left << setw(45) << " " << "-----------------------------------------\n";
	cout << left << setw(45) << " " << left<<setw(20)<< "Do Thanh Long" << "1511799@hcmut.edu.vn\n";
	cout << left << setw(45) << " " << left << setw(20) << "Le Vo Hoang An" << "1510123@hcmut.edu.vn\n";
	cout << left << setw(45) << " " << left << setw(20) << "Dang Luu Chuong" << "1510318@hcmut.edu.vn\n\n";

	cout << left << setw(45) << " " << "Instructors:\n";
	cout << left << setw(45) << " " << "--------------------------------------------------\n";
	cout << left << setw(45) << " " << left << setw(20) << "Le Thanh Sach" << "Bach Khoa university lecturer\n";
	cout << left << setw(45) << " " << left << setw(20) << "Nguyen Duc Dung" << "Bach Khoa university lecturer\n\n";

	cout << left << setw(45) << " " << "press any key to comeback.\n";
	system("pause");

	system("CLS");

}

//in ra logo
void print_logo()
{
	cout << left << setw(45) << " " << "BK libary software\n";
	cout << left << setw(45) << " " << "------------------\n\n";
}

//in man hinh chinh
void main_screen()
{
	while (true)
	{
		int choose;

		print_logo();
		cout << left << setw(45) << " " << "1.Create user\n";
		cout << left << setw(45) << " " << "2.Create account\n";
		cout << left << setw(45) << " " << "3.Login\n";
		cout << left << setw(45) << " " << "4.Change password\n";
		cout << left << setw(45) << "" << "5.Show all book\n";
		cout << left << setw(45) << "" << "6.Find a book\n";
		cout << left << setw(45) << " " << "7.About us\n";
		cout << left << setw(45) << " " << "8.Exit\n\n";

		cout << left << setw(45) << " " << "Choose your option:\n";
		cin >> choose;


		if (choose == 1) {
			system("CLS");
			create_user();
			system("CLS");
		}
		else if (choose == 2) {
			system("CLS");
			create_account();
			system("CLS");
		}
		else if (choose == 3) {
			system("CLS");
			login();
			system("CLS");
		}
		else if (choose == 4)
		{
			system("CLS");
			role helo;
			helo.change_password();

			system("CLS");
		}
		else if (choose == 5)
		{
			system("CLS");
			role showbook;
			showbook.show_all_book();
			system("CLS");
		}
		else if (choose == 6)
		{
			system("CLS");
			role showbook;
			showbook.find_book();
			system("CLS");
		}
		else if (choose == 7)
		{

			system("CLS");
			about_us();
			system("CLS");
		}
		else if (choose == 8)
		{
			exit(0);
		}

	}

}
void create_user()
{
	ofstream user_file;
	string input_name, input_career, input_email;

	int input_number,total_user;

	//seek the total user number
	total_user = seek_total_user();

	

	print_logo();
	cout << left << setw(45) << " " << "Create a new user\n";
	cout << left << setw(45) << " " << "1.Your name:\n";
	cin.ignore(256, '\n');
	getline(cin, input_name);

	cout << left << setw(45) << " " << "2.Your citizen id:\n";
	cin >> input_number;

	cout << left << setw(45) << " " << "3.Your career:\n";
	cin.ignore(256, '\n');
	getline(cin, input_career);

	cout << left << setw(45) << " " << "4.Your email:\n";
	cin >> input_email;

	//open file
	user_file.open("file/user_file.txt", fstream::app);

	//copy to file
	user_file << total_user+1 << "\n";
	user_file << input_name << "\n";
	user_file << input_number << "\n";
	user_file << input_career << "\n";
	user_file << input_email << "\n";
	user_file << "--------------------------------------------------------\n";


	//show to console

	system("CLS");
	cout << left << setw(45) << " " << "create user successfully!\n\n";

	cout << left << setw(45) << " " << left<<setw(20)<<"User ID: "<< total_user + 1 << "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Full name: " << input_name << "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Citizen ID: " << input_number << "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Career: " << input_career << "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Email: " << input_email << "\n";
	
	cout << left << setw(45) << " " << "press any key to comeback.\n";
	system("pause");

	//close file
	user_file.close();

	//comeback to main screen
	system("CLS");
}

void create_account()
{
	int user_id;
	string account_name, account_passwork;

	print_logo();
	cout << left << setw(45) << " " << "create a new account\n";
	cout << left << setw(45) << " " << "Your user ID: \n";
	cin >> user_id;

	//determine user_id has been exist???
	if (!check_user_exist(user_id))
	{
		cout << "this user id hasn't been exist!!!";
		return;
	}
	
	cout << left << setw(45) << " " << "Your account name:\n";
	cin >> account_name;

	cout << left << setw(45) << " " << "Your password:\n";
	cin >> account_passwork;

	ofstream account_file;
	account_file.open("file/account_file.txt", fstream::app);
	account_file << user_id << endl;
	account_file << account_name << "\n";
	account_file << account_passwork << "\n";
	account_file << 4 << endl;
	account_file << 0 << endl;
	account_file <<"-----------------------------------------------\n";
	account_file.close();

	//show to console
	system("CLS");
	cout << left << setw(45) << " " << "create account successfully!\n\n";

	cout << left << setw(45) << " " << left << setw(20) << "User ID: " << user_id << "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Full name: " << account_name<< "\n";
	cout << left << setw(45) << " " << left << setw(20) << "Password: " << account_passwork<< "\n\n";
	cout << left << setw(45) << " " << left << setw(20) << "Status: " << "false" << "\n\n";
	cout << left << setw(45) << " " << "your accout has been sent to account manager to validate.\n";

	cout << left << setw(45) << " " << "press any key to comeback.\n";
	system("pause");

	//comeback to main screen
	system("CLS");
}

//seek the total user number in user.txt file
int seek_total_user()
{
	int total_user;
	ifstream user_file;

	user_file.open("file/user_file.txt");
	if (user_file.peek() == std::ifstream::traits_type::eof())//file is empty
		total_user = 0;
	else {
		int i = 0;
		string tem_string;
		while (true)
		{
			getline(user_file, tem_string);
			i++;
			if (user_file.eof())
				break;
			else if (i % 6 == 1)
			{
				total_user = stoi(tem_string);
			}

		}
	}

	user_file.close();
	return total_user;
}

//load data from user.txt file
vector<user> load_user(int total_user)
{
	vector<user> user_array(total_user);
	ifstream user_file("file/user_file.txt");
	string tem_string;
	
	int i = 0;
	while (true)
	{
		getline(user_file, tem_string);
		i++;
		if (user_file.eof())
			break;

		if (i % 6 == 1) {
			user_array[i/6].user_id= stoi(tem_string);
		}
		else if (i % 6 == 2) {
			user_array[i/6].full_name= tem_string;
		}
		else if (i % 6 == 3) {
			user_array[i/6].citizen_id= stoi(tem_string);
		}
		else if (i % 6 == 4) {
			user_array[i/6].career= tem_string;
		}
		else if (i % 6 == 5)
		{
			user_array[i/6].email= tem_string;
		}
	}

	//for (int i = 0; i < total_user; i++)
	//{
	//	cout << left << setw(20) << "User ID: " << user_array[i].get_user_id() << "\n";
	//	cout << left << setw(20) << "Full name: " << user_array[i].get_full_name() << "\n";
	//	cout << left << setw(20) << "Citizen ID: " << user_array[i].get_citizen_id() << "\n";
	//	cout << left << setw(20) << "Career: " << user_array[i].get_career() << "\n";
	//	cout << left << setw(20) << "Email: " << user_array[i].get_email() << "\n";

	//}
	
	user_file.close();
	return user_array;
}

//check user id has been exist ?
bool check_user_exist(int user_id)
{
	int total_user = seek_total_user();
	vector<user> user_array(total_user);

	user_array = load_user(total_user);
	for (int i = 0; i < total_user; i++)
	{
		if (user_array[i].user_id== user_id)
			return true;
	}
	return false;
}

void login()
{
	string account_name;
	string password;
	role helo;
	vector<account> account_array = helo.load_account();
	account account_login;
	bool flat = false;


	print_logo();
	cout << left << setw(45) << " " << "Login\n";
	cout << left << setw(45) << " " << "------\n";
	cout << left << setw(45) << " " << "Your account:\n";
	cin >> account_name;
	cout << left << setw(45) << " " << "Your password:\n";
	cin >> password;

	for (int i = 0; i < account_array.size(); i++)
	{
		if (account_array[i].account_name == account_name&&account_array[i].password == password&&account_array[i].status==1)
		{
			flat = true;
			account_login = account_array[i];
			if (account_array[i].role==1)
			{
				system("CLS");
				reader_book_screen(account_login);
			}
			else if (account_array[i].role == 2)
			{
				system("CLS");
				account_manager_screen(account_login);
			}
			else if (account_array[i].role == 3)
			{
				system("CLS");
				book_manager_screen(account_login);
			}
		}
	}
	if(flat==false)
		cout << left << setw(45) <<" "<< "your account name or password is wrong!!!\n";
	
	system("pause");
	//comeback to the main screeen
	system("CLS");
	main_screen();
}

//screen of book manager id
void book_manager_screen(account user_login)
{
	
	while (true) {
		int choose;

		print_logo();
		cout << left << setw(45) << " " << "Book manager screeen\n";
		cout << left << setw(45) << " " << "---------------------\n\n";
		cout << left << setw(45) << " " << "1.Show personal information\n";
		cout << left << setw(45) << " " << "2.Add book\n";
		cout << left << setw(45) << " " << "3.Modify book\n";
		cout << left << setw(45) << " " << "4.Delete book\n";
		cout << left << setw(45) << " " << "5.Allow borrow book\n";
		cout << left << setw(45) << " " << "6.Log out\n";
		cout << left << setw(45) << " " << "Choose your option\n";
		cin >> choose;

		if (choose == 1)
		{
			system("CLS");
			role helo;
			helo.see_personal_information(user_login);
		}
		else if (choose == 2)
		{
			system("CLS");
			book_manager helo;
			helo.insert_book();
			system("CLS");

		}
		else if (choose == 3)
		{
			system("CLS");
			book_manager helo;
			helo.modify_book();
			system("CLS");
		}
		else if (choose == 4)
		{
			system("CLS");
			book_manager helo;
			helo.delete_book();
			system("CLS");
		}
		else if (choose == 5)
		{
			system("CLS");
			book_manager helo;
			helo.allow_borrow();
			system("CLS");
		}
		else if (choose == 6)
		{
			system("CLS");
			return;
		}
		
	}
}

//screen of reader
void reader_book_screen(account user_login) {
	while (true) {
		int choose;

		print_logo();
		cout << left << setw(45) << " " << "Reader screeen\n";
		cout << left << setw(45) << " " << "--------------\n\n";
		cout << left << setw(45) << " " << "1.Show personal information\n";
		cout << left << setw(45) << " " << "2.Borrow book\n";
		cout << left << setw(45) << " " << "3.pay book\n";
		cout << left << setw(45) << " " << "4.log out\n";
		cout << left << setw(45) << " " << "Choose your option\n";
		cin >> choose;

		if (choose == 1)
		{
			system("CLS");
			role helo;
			helo.see_personal_information(user_login);
		}
		else if (choose == 2)
		{
			system("CLS");
			reader helo;
			helo.borrow_book(user_login);
			system("CLS");

		}
		else if (choose == 3)
		{
			system("CLS");
			reader helo;
			helo.pay_book(user_login);
			system("CLS");
		}
		else if (choose == 4)
		{
			system("CLS");
			return;
		}

	}
}

//screen of account manager
void account_manager_screen(account account_login) {
	while (true) {
		int choose;

		print_logo();
		cout << left << setw(45) << " " << "Account manager screeen\n";
		cout << left << setw(45) << " " << "------------------------\n\n";
		cout << left << setw(45) << " " << "1.Show personal information\n";
		cout << left << setw(45) << " " << "2.Active account\n";
		cout << left << setw(45) << " " << "3.reset password\n";
		cout << left << setw(45) << " " << "4.Delete account\n";
		cout << left << setw(45) << " " << "5.Block account\n";
		cout << left << setw(45) << " " << "6.Show all account\n";
		cout << left << setw(45) << " " << "7.Find account\n";
		cout << left << setw(45) << " " << "8.log out\n";
		cout << left << setw(45) << " " << "Choose your option\n";
		cin >> choose;

		if (choose == 1)
		{
			system("CLS");
			role helo;
			helo.see_personal_information(account_login);
		}
		else if (choose == 2)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.active_account();
			system("CLS");
		}
		else if (choose == 3)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.reset_password();
			system("CLS");
		}
		else if (choose == 4)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.delete_account();
			system("CLS");
		}
		else if (choose == 5)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.block_account();
			system("CLS");
		}
		else if (choose == 6)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.show_all_account();
			system("CLS");
		}
		else if (choose == 7)
		{
			system("CLS");
			account_manager account_mag;
			account_mag.search_account();
			system("CLS");
		}
		else if (choose == 8)
		{
			system("CLS");
			return;
		}
	}
}