#ifndef ROLE_H_
#define ROLE_H_
#include<iostream>
#include<fstream>
#include<iomanip>
#include"display.h"
using namespace std;



class role
{
private:
public:
	int seek_total_book();
	vector<book> load_book();
	bool check_book_exist(int id);
	void write_book(vector<book> book_array);
	void show_all_book();
	void find_book();
	vector<account> load_account();
	void see_personal_information(account account_login);
	bool check_account_exist(string acoount_name);
	void change_password();
	void write_account(vector<account> account_array);
	int seek_total_account();
	vector<borrow_table> load_borrow_book();
	int seek_total_borrow();
	void write_borrow(vector<borrow_table> borrow);
	bool borrow_exist(int book_id, int user_id);
};

class reader:public role
{
private:

public:
	void borrow_book(account account_id);
	void pay_book(account account_id);

};

class account_manager :public role {
private:
public:
	void active_account();
	void reset_password();
	void delete_account();
	void block_account();
	void show_all_account();
	void search_account();
};//an
class book_manager:public role
{
private:

public:
	void insert_book();
	void delete_book();
	void modify_book();
	void allow_borrow();
};


#endif // !ROLE_H_
