#ifndef DISPLAY_H_
#define DISPLAY_H_
#include<iostream>
using namespace std;

void about_us();
void print_logo();
void main_screen();
void create_user();

#endif // !DISPLAY_H_
