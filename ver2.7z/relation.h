﻿#ifndef RELATION_H_
#define RELATION_H_
#include<iostream>
#include<string>
using namespace std;

//bảng ánh xạ giữa user và account
struct user_account
{
	int user_id;
	string account_no;
};

//bảng ánh xạ giữa account và role
struct account_role
{
	string account_no;
	enum role{ reader_role=1,book_mang_role,user_mang_role };
};
struct book
{
	int id;
	string name;
	string author;
	int total;
};
#endif