#ifndef ACCOUNT_H_
#define ACCOUNT_H_
#include<iostream>
#include<string>
using namespace std;
class account
{
private:
	string account_no;
	string password;
	bool status;
public:

};
#endif // !ACCOUNT_H_

