#include<iostream>
#include"user.h"
#include"role.h"
#include"account.h"
#include"relation.h"
#include"display.h"
int main()
{
	system("color 1A");
	bool loop;

	main_screen();

	
		
	system("pause");
	return 0;
}