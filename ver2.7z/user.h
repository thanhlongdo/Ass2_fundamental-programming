#ifndef USER_H_
#define USER_H_
#include<iostream>
#include<string>
using namespace std;
class user
{
private:
	int user_id;
	string full_name;
	int citizen_id;
	string career;
	string email;
public:



};
#endif 