#include"display.h"
#include<iomanip>
#include<fstream>
#include<string>

//in thong tin
void about_us()
{
	int choose;

	print_logo();

	cout << "Team members:\n";
	cout << "---------------------------------------------------------\n";
	cout <<left<<setw(20)<< "Do Thanh Long" << "1511799@hcmut.edu.vn\n";
	cout << left << setw(20) << "Le Vo Hoang An" << "1510123@hcmut.edu.vn\n";
	cout << left << setw(20) << "Dang Luu Chuong" << "1510318@hcmut.edu.vn\n\n";

	cout << "Instructors:\n";
	cout << "---------------------------------------------------------\n";
	cout << left << setw(20) << "Le Thanh Sach" << "Bach Khoa university lecturer\n";
	cout << left << setw(20) << "Nguyen Duc Dung" << "Bach Khoa university lecturer\n\n";

	cout << "press any key to comeback.\n";
	cin >> choose;

	system("CLS");
	main_screen();

}

//in ra logo
void print_logo()
{
	cout << "BK libary software\n";
	cout << "----------------------\n\n";
}

//in man hinh chinh
void main_screen()
{
	int choose;

	cout << "BK libary software\n";
	cout << "----------------------\n\n";
	cout << "1.Create user\n";
	cout << "2.Create account.\n";
	cout << "3.Login\n";
	cout << "4.About us\n";
	cout << "5.Exit\n\n";

	cout << "Choose your option:\n";
	cin >> choose;


	if (choose == 1) {
		system("CLS");
		create_user();
	}
	else if (choose == 2)
		cout << "choose 2";
	else if (choose == 3)
		return;
	else if (choose == 4)
	{
		system("CLS");
		about_us();
	}
	else if (choose == 5)
		return;
}

void create_user()
{
	ofstream user_file;
	string input;
	int number;

	user_file.open("file/user_file.txt", fstream::app);

	print_logo();
	cout << "Create a new user\n";
	cout << "1.Your name:\n";
	getline(cin, input);
	user_file << input << "\n";
	
	cout << "2.Your citizen id:\n";
	cin >> number;
	user_file << number << "\n";

	cout << "3.Your career:\n";
	cin >> number;
	user_file << number << "\n";

	cout << "4.Your email:\n";
	cin >> input;
	user_file << input << "\n";

	system("CLS");
	cout << "create user successfully!\n";

	cin >> input;

	//comeback to main screen
	system("CLS");
	main_screen();
}